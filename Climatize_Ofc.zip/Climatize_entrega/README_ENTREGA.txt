CLIMATIZE - VERSAO PARA ENTREGA

Principais correcoes feitas:
1. Corrigido o classpath das bibliotecas MySQL Connector e BCrypt para a pasta lib.
2. Corrigida a classe principal para abrir a TelaLogin.
3. Removida referencia antiga de campo de senha da TelaLogin.
4. Corrigido texto de placeholder da pesquisa de funcionario.
5. Criada TelaMenuFuncionario usando a Sessao existente.
6. Criada TelaPerguntas usando PerguntaController existente.
7. Criada TelaPesquisa usando PesquisaController/PerguntaController existentes.
8. Criada TelaResultados usando ResultadoController existente.
9. Ligados os botoes Perguntas e Resultados do Menu Gestor.
10. Removida a pasta nbproject/private para evitar configuracoes do computador anterior.

TESTE DE COMPILACAO:
- O projeto foi compilado com sucesso em ambiente Java 21 apenas para validar o codigo.
- O projeto continua configurado com source/target 25, conforme o projeto original.
- Para executar no seu computador, use JDK 25 no NetBeans.

NO NETBEANS:
1. Abra o projeto.
2. Confirme que o projeto usa JDK 25.
3. Confirme que o MySQL esta ligado e que o banco clima_tcc existe.
4. Clique em Clean and Build.
5. Clique em Run.
6. Teste o login do gestor.

CREDENCIAL DE TESTE DO PROJETO:
E-mail: gestor@escola.com
Senha: 123456

IMPORTANTE:
O ZIP original nao continha um arquivo SQL/schema. Portanto, as tabelas e constraints do banco nao puderam ser validadas automaticamente. A conexao existente continua apontando para:
jdbc:mysql://localhost:3306/clima_tcc
usuario: root
senha: vazia
