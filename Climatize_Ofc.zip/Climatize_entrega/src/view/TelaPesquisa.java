/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import Controller.PerguntaController;
import Controller.PesquisaController;
import model.Pergunta;
import model.RespostaItem;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.BoxLayout;

public class TelaPesquisa extends javax.swing.JFrame {
    
    private PerguntaController perguntaController;
    private PesquisaController pesquisaController;
    private ArrayList<Pergunta> perguntas;
    private ArrayList<JComboBox<Integer>> camposNotas;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(TelaPesquisa.class.getName());

    /**
     * Creates new form TelaPesquisa
     */
    public TelaPesquisa() {
        initComponents();
        
        pnlPerguntas.setPreferredSize(
            new java.awt.Dimension(500, 350)
    );

    setLocationRelativeTo(null);

    perguntaController = new PerguntaController();
    pesquisaController = new PesquisaController();

    perguntas = new ArrayList<>();
    camposNotas = new ArrayList<>();

    if (Controller.Sessao.funcionarioEstaLogado()) {
         carregarPerguntas();

    if (perguntas.size() == 10) {
        carregarRespostaAnterior();
    }
    }
    }

    private void carregarPerguntas() {

    try {

        perguntas = perguntaController.listar();

        if (perguntas.size() != 10) {

            JOptionPane.showMessageDialog(
                    this,
                    "É necessário cadastrar exatamente 10 perguntas no banco de dados.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        configurarPainelPerguntas();

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Erro ao carregar perguntas:\n" + e.getMessage(),
                "Erro",
                JOptionPane.ERROR_MESSAGE
        );

    }
}
    private void configurarPainelPerguntas() {

    pnlPerguntas.removeAll();

    pnlPerguntas.setLayout(
            new BoxLayout(
                    pnlPerguntas,
                    BoxLayout.Y_AXIS
            )
    );

    camposNotas.clear();

    for (Pergunta pergunta : perguntas) {

        JPanel linha = new JPanel(
                new java.awt.FlowLayout(
                        java.awt.FlowLayout.LEFT
                )
        );

        JLabel lblPergunta = new JLabel(
                pergunta.getId() + ". " + pergunta.getTexto()
        );

        JComboBox<Integer> comboNota = new JComboBox<>();

        for (int nota = 0; nota <= 10; nota++) {
            comboNota.addItem(nota);
        }

        // Nenhuma nota selecionada inicialmente
        comboNota.setSelectedIndex(-1);

        linha.add(lblPergunta);
        linha.add(comboNota);

        pnlPerguntas.add(linha);

        camposNotas.add(comboNota);
    }

    pnlPerguntas.revalidate();
    pnlPerguntas.repaint();
}
    
    private void carregarRespostaAnterior() {

    try {

        model.Resposta resposta =
                pesquisaController.buscarMinhaResposta();

        if (resposta != null) {

            if (resposta.getComentario() != null) {

                txtComentario.setText(
                        resposta.getComentario()
                );

            }

            ArrayList<RespostaItem> itens =
                    pesquisaController.buscarMinhasNotas();

            Map<Integer, Integer> notas =
                    new HashMap<>();

            for (RespostaItem item : itens) {

                notas.put(
                        item.getPerguntaId(),
                        item.getNota()
                );

            }

            for (int i = 0; i < perguntas.size(); i++) {

                int perguntaId =
                        perguntas.get(i).getId();

                Integer nota =
                        notas.get(perguntaId);

                if (nota != null) {

                    camposNotas.get(i).setSelectedItem(nota);

                }

            }

        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Erro ao carregar resposta anterior:\n"
                + e.getMessage(),
                "Erro",
                JOptionPane.ERROR_MESSAGE
        );

    }
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitulo = new javax.swing.JLabel();
        pnlPerguntas = new javax.swing.JPanel();
        lblComentario = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtComentario = new javax.swing.JTextArea();
        btnSalvar = new javax.swing.JButton();
        btnVoltar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        lblTitulo.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTitulo.setText("Pesquisa de Clima Organizacional");

        javax.swing.GroupLayout pnlPerguntasLayout = new javax.swing.GroupLayout(pnlPerguntas);
        pnlPerguntas.setLayout(pnlPerguntasLayout);
        pnlPerguntasLayout.setHorizontalGroup(
            pnlPerguntasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );
        pnlPerguntasLayout.setVerticalGroup(
            pnlPerguntasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 137, Short.MAX_VALUE)
        );

        lblComentario.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblComentario.setText("Comentário:");

        txtComentario.setColumns(20);
        txtComentario.setRows(5);
        jScrollPane1.setViewportView(txtComentario);

        btnSalvar.setText("Enviar Pesquisa");
        btnSalvar.addActionListener(this::btnSalvarActionPerformed);

        btnVoltar.setText("Voltar");
        btnVoltar.addActionListener(this::btnVoltarActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(106, 106, 106)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(pnlPerguntas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblComentario)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1)))
                .addContainerGap(110, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(199, 199, 199))
            .addGroup(layout.createSequentialGroup()
                .addGap(167, 167, 167)
                .addComponent(btnSalvar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnVoltar)
                .addGap(150, 150, 150))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(lblTitulo)
                .addGap(46, 46, 46)
                .addComponent(pnlPerguntas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblComentario)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalvar)
                    .addComponent(btnVoltar))
                .addGap(82, 82, 82))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        if (camposNotas.size() != 10) {

        JOptionPane.showMessageDialog(
                this,
                "As 10 perguntas precisam estar carregadas.",
                "Aviso",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    int[] notas = new int[10];

    for (int i = 0; i < camposNotas.size(); i++) {

        JComboBox<Integer> comboNota = camposNotas.get(i);

        if (comboNota.getSelectedItem() == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Responda todas as perguntas antes de salvar.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        notas[i] = (Integer) comboNota.getSelectedItem();
    }

    String comentario = txtComentario.getText().trim();

    try {

        pesquisaController.salvarPesquisa(
                notas,
                comentario
        );

        JOptionPane.showMessageDialog(
                this,
                "Pesquisa salva com sucesso!",
                "Sucesso",
                JOptionPane.INFORMATION_MESSAGE
        );

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Erro ao salvar pesquisa:\n" + e.getMessage(),
                "Erro",
                JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_btnSalvarActionPerformed

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        new TelaMenuFuncionario().setVisible(true);
        dispose();
    }//GEN-LAST:event_btnVoltarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new TelaPesquisa().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSalvar;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblComentario;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JPanel pnlPerguntas;
    private javax.swing.JTextArea txtComentario;
    // End of variables declaration//GEN-END:variables
}
