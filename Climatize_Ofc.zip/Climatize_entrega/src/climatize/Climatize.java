package climatize;

import javax.swing.SwingUtilities;
import view.TelaLogin;

public class Climatize {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new TelaLogin().setVisible(true);
        });
    }
}
