/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import model.Resultado;
import java.sql.SQLException;
import java.util.ArrayList;

public class ResultadoController {

    private ResultadoDAO resultadoDAO;

    public ResultadoController() {
        resultadoDAO = new ResultadoDAO();
    }

    // Buscar média de cada pergunta
    public ArrayList<Resultado> buscarMedias()
            throws SQLException {

        // Somente o gestor pode consultar os resultados
        if (!Sessao.gestorEstaLogado()) {
            throw new SQLException(
                    "Acesso permitido somente ao gestor."
            );
        }

        return resultadoDAO.listarMedias();
    }

    // Buscar média geral
    public double buscarMediaGeral()
            throws SQLException {

        if (!Sessao.gestorEstaLogado()) {
            throw new SQLException(
                    "Acesso permitido somente ao gestor."
            );
        }

        return resultadoDAO.calcularMediaGeral();
    }

    // Buscar quantidade de respostas
    public int buscarQuantidadeRespostas()
            throws SQLException {

        if (!Sessao.gestorEstaLogado()) {
            throw new SQLException(
                    "Acesso permitido somente ao gestor."
            );
        }

        return resultadoDAO.quantidadeRespostas();
    }
}
