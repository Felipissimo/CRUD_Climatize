/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import model.Resposta;
import model.RespostaItem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class RespostaDAO {

    private Connection conexao;

    public RespostaDAO() {
        try {
            conexao = Conexao.getConexao();
        } catch (SQLException e) {
            System.out.println("Erro ao conectar com o banco: "
                    + e.getMessage());
        }
    }

    // Cadastrar resposta
    public long cadastrar(Resposta resposta) throws SQLException {

        String sql = "INSERT INTO respostas "
                + "(funcionario_id, comentario) "
                + "VALUES (?, ?)";

        PreparedStatement ps = conexao.prepareStatement(
                sql,
                PreparedStatement.RETURN_GENERATED_KEYS
        );

        ps.setInt(1, resposta.getFuncionarioId());
        ps.setString(2, resposta.getComentario());

        ps.executeUpdate();

        ResultSet rs = ps.getGeneratedKeys();

        long idResposta = 0;

        if (rs.next()) {
            idResposta = rs.getLong(1);
        }

        rs.close();
        ps.close();

        return idResposta;
    }

    // Cadastrar item da resposta
    public void cadastrarItem(RespostaItem item)
            throws SQLException {

        String sql = "INSERT INTO resposta_itens "
                + "(resposta_id, pergunta_id, nota) "
                + "VALUES (?, ?, ?)";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setLong(1, item.getRespostaId());
        ps.setInt(2, item.getPerguntaId());
        ps.setInt(3, item.getNota());

        ps.executeUpdate();

        ps.close();
    }

    // Pesquisar resposta pelo funcionário
    public Resposta pesquisarPorFuncionario(int funcionarioId)
            throws SQLException {

        String sql = "SELECT * FROM respostas "
                + "WHERE funcionario_id = ?";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setInt(1, funcionarioId);

        ResultSet rs = ps.executeQuery();

        Resposta resposta = null;

        if (rs.next()) {

            resposta = new Resposta();

            resposta.setId(rs.getLong("id"));
            resposta.setFuncionarioId(
                    rs.getInt("funcionario_id")
            );
            resposta.setComentario(
                    rs.getString("comentario")
            );
        }

        rs.close();
        ps.close();

        return resposta;
    }

    // Buscar itens de uma resposta
    public ArrayList<RespostaItem> listarItens(long respostaId)
            throws SQLException {

        String sql = "SELECT * FROM resposta_itens "
                + "WHERE resposta_id = ? "
                + "ORDER BY pergunta_id";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setLong(1, respostaId);

        ResultSet rs = ps.executeQuery();

        ArrayList<RespostaItem> itens = new ArrayList<>();

        while (rs.next()) {

            RespostaItem item = new RespostaItem();

            item.setId(rs.getLong("id"));
            item.setRespostaId(
                    rs.getLong("resposta_id")
            );
            item.setPerguntaId(
                    rs.getInt("pergunta_id")
            );
            item.setNota(
                    rs.getInt("nota")
            );

            itens.add(item);
        }

        rs.close();
        ps.close();

        return itens;
    }

    // Alterar comentário da resposta
    public void alterar(Resposta resposta) throws SQLException {

        String sql = "UPDATE respostas SET "
                + "comentario = ? "
                + "WHERE id = ?";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setString(1, resposta.getComentario());
        ps.setLong(2, resposta.getId());

        ps.executeUpdate();

        ps.close();
    }

    // Alterar nota de um item
    public void alterarItem(RespostaItem item)
            throws SQLException {

        String sql = "UPDATE resposta_itens SET "
                + "nota = ? "
                + "WHERE resposta_id = ? "
                + "AND pergunta_id = ?";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setInt(1, item.getNota());
        ps.setLong(2, item.getRespostaId());
        ps.setInt(3, item.getPerguntaId());

        ps.executeUpdate();

        ps.close();
    }

    // Excluir item de uma resposta
    public void excluirItem(long respostaId, int perguntaId)
            throws SQLException {

        String sql = "DELETE FROM resposta_itens "
                + "WHERE resposta_id = ? "
                + "AND pergunta_id = ?";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setLong(1, respostaId);
        ps.setInt(2, perguntaId);

        ps.executeUpdate();

        ps.close();
    }

    // Excluir resposta
    public void excluir(long id) throws SQLException {

        String sql = "DELETE FROM respostas WHERE id = ?";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setLong(1, id);

        ps.executeUpdate();

        ps.close();
    }

public long salvarPesquisa(
        int funcionarioId,
        int[] notas,
        String comentario) throws SQLException {

    if (notas == null || notas.length != 10) {
        throw new SQLException(
                "A pesquisa deve possuir exatamente 10 notas."
        );
    }

   
    conexao.setAutoCommit(false);

    try {

        Resposta respostaExistente =
                pesquisarPorFuncionario(funcionarioId);

        long respostaId;

        if (respostaExistente == null) {

            Resposta resposta = new Resposta();

            resposta.setFuncionarioId(funcionarioId);
            resposta.setComentario(comentario);

            respostaId = cadastrar(resposta);

        } else {

            respostaId = respostaExistente.getId();

            respostaExistente.setComentario(comentario);

            alterar(respostaExistente);
        }

        for (int i = 0; i < notas.length; i++) {

            int perguntaId = i + 1;
            int nota = notas[i];

            if (nota < 0 || nota > 10) {
                throw new SQLException(
                        "A nota deve estar entre 0 e 10."
                );
            }

            RespostaItem item = new RespostaItem();

            item.setRespostaId(respostaId);
            item.setPerguntaId(perguntaId);
            item.setNota(nota);

            if (respostaExistente == null) {
                cadastrarItem(item);
            } else {
                alterarItem(item);
            }
        }

        conexao.commit();

        return respostaId;

    } catch (SQLException e) {

        conexao.rollback();

        throw e;

    } finally {

        conexao.setAutoCommit(true);
    }
}
}
