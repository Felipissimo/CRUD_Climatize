/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

public class TestarLogin {

    public static void main(String[] args) {

        try {

            LoginController loginController =
                    new LoginController();

            String email = "gestor@escola.com";
            String senha = "123456";

            boolean entrou =
                    loginController.entrar(email, senha);

            if (entrou) {

                System.out.println("Login realizado com sucesso!");

                if (loginController.gestorEstaLogado()) {

                    System.out.println(
                            "Tipo de usuário: GESTOR"
                    );

                    System.out.println(
                            "Nome: "
                            + Sessao.getGestorLogado().getNome()
                    );

                } else if (
                        loginController.funcionarioEstaLogado()) {

                    System.out.println(
                            "Tipo de usuário: FUNCIONÁRIO"
                    );

                    System.out.println(
                            "Nome: "
                            + Sessao.getFuncionarioLogado().getNome()
                    );
                }

            } else {

                System.out.println(
                        "E-mail ou senha incorretos."
                );
            }

        } catch (Exception e) {

            System.out.println(
                    "Erro ao realizar login: "
                    + e.getMessage()
            );
        }
    }
}