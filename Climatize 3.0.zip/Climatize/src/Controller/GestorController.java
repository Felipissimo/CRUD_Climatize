/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import model.Gestor;
import java.sql.SQLException;

public class GestorController {

    private GestorDAO gestorDAO;

    public GestorController() {
        gestorDAO = new GestorDAO();
    }

    // Cadastrar gestor
    public void cadastrar(Gestor gestor, String senha)
            throws SQLException {

        if (gestor == null) {
            throw new SQLException("Gestor inválido.");
        }

        if (gestor.getNome() == null
                || gestor.getNome().trim().isEmpty()) {
            throw new SQLException("Informe o nome do gestor.");
        }

        if (gestor.getEmail() == null
                || gestor.getEmail().trim().isEmpty()) {
            throw new SQLException("Informe o e-mail do gestor.");
        }

        if (senha == null || senha.isEmpty()) {
            throw new SQLException("Informe a senha.");
        }

        gestorDAO.cadastrar(gestor, senha);
    }

    // Pesquisar gestor
    public Gestor pesquisar(int id)
            throws SQLException {

        return gestorDAO.pesquisar(id);
    }

    // Alterar gestor
    public void alterar(Gestor gestor)
            throws SQLException {

        if (gestor == null) {
            throw new SQLException("Gestor inválido.");
        }

        if (gestor.getNome() == null
                || gestor.getNome().trim().isEmpty()) {
            throw new SQLException("Informe o nome do gestor.");
        }

        if (gestor.getEmail() == null
                || gestor.getEmail().trim().isEmpty()) {
            throw new SQLException("Informe o e-mail do gestor.");
        }

        gestorDAO.alterar(gestor);
    }

    // Alterar senha
    public void alterarSenha(int id, String novaSenha)
            throws SQLException {

        if (novaSenha == null || novaSenha.isEmpty()) {
            throw new SQLException("Informe a nova senha.");
        }

        gestorDAO.alterarSenha(id, novaSenha);
    }

    // Excluir gestor
    public void excluir(int id)
            throws SQLException {

        gestorDAO.excluir(id);
    }

    // Login
    public Gestor login(String email, String senha)
            throws SQLException {

        if (email == null || email.trim().isEmpty()) {
            throw new SQLException("Informe o e-mail.");
        }

        if (senha == null || senha.isEmpty()) {
            throw new SQLException("Informe a senha.");
        }

        return gestorDAO.login(email, senha);
    }
}
