/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import model.Pergunta;
import java.sql.SQLException;
import java.util.ArrayList;

public class PerguntaController {

    private PerguntaDAO perguntaDAO;

    public PerguntaController() {
        perguntaDAO = new PerguntaDAO();
    }

    // Cadastrar pergunta
    public void cadastrar(Pergunta pergunta)
            throws SQLException {

        verificarGestor();

        if (pergunta == null) {
            throw new SQLException("Pergunta inválida.");
        }

        if (pergunta.getTexto() == null
                || pergunta.getTexto().trim().isEmpty()) {
            throw new SQLException("Informe o texto da pergunta.");
        }

        perguntaDAO.cadastrar(pergunta);
    }

    // Pesquisar pergunta
    public Pergunta pesquisar(int id)
            throws SQLException {

        verificarGestor();

        return perguntaDAO.pesquisar(id);
    }

    // Listar perguntas
    public ArrayList<Pergunta> listar()
            throws SQLException {

        return perguntaDAO.listar();
    }

    // Alterar pergunta
    public void alterar(Pergunta pergunta)
            throws SQLException {

        verificarGestor();

        if (pergunta == null) {
            throw new SQLException("Pergunta inválida.");
        }

        if (pergunta.getTexto() == null
                || pergunta.getTexto().trim().isEmpty()) {
            throw new SQLException("Informe o texto da pergunta.");
        }

        perguntaDAO.alterar(pergunta);
    }

    // Excluir pergunta
    public void excluir(int id)
            throws SQLException {

        verificarGestor();

        perguntaDAO.excluir(id);
    }

    // Verifica se existe um gestor logado
    private void verificarGestor()
            throws SQLException {

        if (!Sessao.gestorEstaLogado()) {
            throw new SQLException(
                    "Acesso permitido somente ao gestor."
            );
        }
    }
}
