/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import model.Resultado;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ResultadoDAO {

    private Connection conexao;

    public ResultadoDAO() {
        try {
            conexao = Conexao.getConexao();
        } catch (SQLException e) {
            System.out.println("Erro ao conectar com o banco: "
                    + e.getMessage());
        }
    }

    // Calcula a média de cada pergunta
    public ArrayList<Resultado> listarMedias()
            throws SQLException {

        String sql =
                "SELECT p.id, p.texto, "
                + "AVG(ri.nota) AS media "
                + "FROM perguntas p "
                + "LEFT JOIN resposta_itens ri "
                + "ON p.id = ri.pergunta_id "
                + "GROUP BY p.id, p.texto "
                + "ORDER BY p.id";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        ArrayList<Resultado> resultados = new ArrayList<>();

        while (rs.next()) {

            Resultado resultado = new Resultado();

            resultado.setPerguntaId(
                    rs.getInt("id")
            );

            resultado.setPergunta(
                    rs.getString("texto")
            );

            resultado.setMedia(
                    rs.getDouble("media")
            );

            resultados.add(resultado);
        }

        rs.close();
        ps.close();

        return resultados;
    }

    // Calcula a média geral da pesquisa
    public double calcularMediaGeral()
            throws SQLException {

        String sql =
                "SELECT AVG(nota) AS media "
                + "FROM resposta_itens";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        double media = 0;

        if (rs.next()) {
            media = rs.getDouble("media");
        }

        rs.close();
        ps.close();

        return media;
    }

    // Quantidade de funcionários que responderam
    public int quantidadeRespostas()
            throws SQLException {

        String sql =
                "SELECT COUNT(*) AS total "
                + "FROM respostas";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        int total = 0;

        if (rs.next()) {
            total = rs.getInt("total");
        }

        rs.close();
        ps.close();

        return total;
    }
}
