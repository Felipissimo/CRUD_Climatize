/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import model.Resposta;
import java.sql.SQLException;
import java.util.ArrayList;

public class PesquisaController {

    private RespostaDAO respostaDAO;

    public PesquisaController() {
        respostaDAO = new RespostaDAO();
    }

    // Salvar ou alterar a pesquisa
    public long salvarPesquisa(int[] notas, String comentario)
            throws SQLException {

        // Verifica se existe funcionário logado
        if (!Sessao.funcionarioEstaLogado()) {
            throw new SQLException(
                    "Nenhum funcionário está logado."
            );
        }

        // Verifica se foram informadas exatamente 10 notas
        if (notas == null || notas.length != 10) {
            throw new SQLException(
                    "A pesquisa deve possuir exatamente 10 notas."
            );
        }

        // Verifica se todas as notas estão entre 0 e 10
        for (int nota : notas) {

            if (nota < 0 || nota > 10) {
                throw new SQLException(
                        "As notas devem estar entre 0 e 10."
                );
            }
        }

        int funcionarioId =
                Sessao.getFuncionarioLogado().getId();

        return respostaDAO.salvarPesquisa(
                funcionarioId,
                notas,
                comentario
        );
    }

    // Buscar a pesquisa do funcionário logado
    public Resposta buscarMinhaResposta()
            throws SQLException {

        if (!Sessao.funcionarioEstaLogado()) {
            throw new SQLException(
                    "Nenhum funcionário está logado."
            );
        }

        int funcionarioId =
                Sessao.getFuncionarioLogado().getId();

        return respostaDAO.pesquisarPorFuncionario(
                funcionarioId
        );
    }

    // Buscar as notas da pesquisa do funcionário logado
    public ArrayList<model.RespostaItem> buscarMinhasNotas()
            throws SQLException {

        Resposta resposta = buscarMinhaResposta();

        if (resposta == null) {
            return new ArrayList<>();
        }

        return respostaDAO.listarItens(
                resposta.getId()
        );
    }
}