/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import model.Funcionario;
import model.Gestor;

public class Sessao {

    private static Funcionario funcionarioLogado;
    private static Gestor gestorLogado;


    public static void iniciarFuncionario(Funcionario funcionario) {
        funcionarioLogado = funcionario;
        gestorLogado = null;
    }

    public static Funcionario getFuncionarioLogado() {
        return funcionarioLogado;
    }


    public static void iniciarGestor(Gestor gestor) {
        gestorLogado = gestor;
        funcionarioLogado = null;
    }

    public static Gestor getGestorLogado() {
        return gestorLogado;
    }


    public static boolean funcionarioEstaLogado() {
        return funcionarioLogado != null;
    }

    public static boolean gestorEstaLogado() {
        return gestorLogado != null;
    }


    public static void encerrar() {
        funcionarioLogado = null;
        gestorLogado = null;
    }
}
