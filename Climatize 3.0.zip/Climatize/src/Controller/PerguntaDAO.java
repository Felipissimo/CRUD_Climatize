/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import model.Pergunta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PerguntaDAO {

    private Connection conexao;

    public PerguntaDAO() {
        try {
            conexao = Conexao.getConexao();
        } catch (SQLException e) {
            System.out.println("Erro ao conectar com o banco: "
                    + e.getMessage());
        }
    }

    // Cadastrar pergunta
    public void cadastrar(Pergunta pergunta) throws SQLException {

        String sql = "INSERT INTO perguntas (id, texto) "
                + "VALUES (?, ?)";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setInt(1, pergunta.getId());
        ps.setString(2, pergunta.getTexto());

        ps.executeUpdate();

        ps.close();
    }

    // Pesquisar pergunta pelo ID
    public Pergunta pesquisar(int id) throws SQLException {

        String sql = "SELECT * FROM perguntas WHERE id = ?";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setInt(1, id);

        ResultSet rs = ps.executeQuery();

        Pergunta pergunta = null;

        if (rs.next()) {

            pergunta = new Pergunta();

            pergunta.setId(rs.getInt("id"));
            pergunta.setTexto(rs.getString("texto"));
        }

        rs.close();
        ps.close();

        return pergunta;
    }

    // Listar todas as perguntas
    public ArrayList<Pergunta> listar() throws SQLException {

        String sql = "SELECT * FROM perguntas ORDER BY id";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        ArrayList<Pergunta> perguntas = new ArrayList<>();

        while (rs.next()) {

            Pergunta pergunta = new Pergunta();

            pergunta.setId(rs.getInt("id"));
            pergunta.setTexto(rs.getString("texto"));

            perguntas.add(pergunta);
        }

        rs.close();
        ps.close();

        return perguntas;
    }

    // Alterar pergunta
    public void alterar(Pergunta pergunta) throws SQLException {

        String sql = "UPDATE perguntas SET "
                + "texto = ? "
                + "WHERE id = ?";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setString(1, pergunta.getTexto());
        ps.setInt(2, pergunta.getId());

        ps.executeUpdate();

        ps.close();
    }

    // Excluir pergunta
    public void excluir(int id) throws SQLException {

        String sql = "DELETE FROM perguntas WHERE id = ?";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setInt(1, id);

        ps.executeUpdate();

        ps.close();
    }
}
