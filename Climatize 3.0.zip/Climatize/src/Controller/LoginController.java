/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import model.Funcionario;
import model.Gestor;
import java.sql.SQLException;

public class LoginController {

    private GestorController gestorController;
    private FuncionarioController funcionarioController;

    public LoginController() {
        gestorController = new GestorController();
        funcionarioController = new FuncionarioController();
    }

    public boolean entrar(String email, String senha)
            throws SQLException {

        if (email == null || email.trim().isEmpty()) {
            throw new SQLException("Informe o e-mail.");
        }

        if (senha == null || senha.isEmpty()) {
            throw new SQLException("Informe a senha.");
        }

        email = email.trim();

        // Primeiro verifica se é um gestor
        Gestor gestor = gestorController.login(email, senha);

        if (gestor != null) {
            Sessao.iniciarGestor(gestor);
            return true;
        }

        // Se não for gestor, verifica se é funcionário
        Funcionario funcionario =
                funcionarioController.login(email, senha);

        if (funcionario != null) {
            Sessao.iniciarFuncionario(funcionario);
            return true;
        }

        return false;
    }

    public void sair() {
        Sessao.encerrar();
    }

    public boolean gestorEstaLogado() {
        return Sessao.gestorEstaLogado();
    }

    public boolean funcionarioEstaLogado() {
        return Sessao.funcionarioEstaLogado();
    }
}
