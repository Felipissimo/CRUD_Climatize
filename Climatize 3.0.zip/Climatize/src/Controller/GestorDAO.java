/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Controller;

import model.Gestor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.mindrot.jbcrypt.BCrypt;

public class GestorDAO {

    private Connection conexao;

    public GestorDAO() {
        try {
            conexao = Conexao.getConexao();
        } catch (SQLException e) {
            System.out.println("Erro ao conectar com o banco: "
                    + e.getMessage());
        }
    }

    public void cadastrar(Gestor gestor, String senha)
            throws SQLException {

        String senhaHash = BCrypt.hashpw(
                senha,
                BCrypt.gensalt()
        );

        String sql = "INSERT INTO gestores "
                + "(nome, email, senha_hash) "
                + "VALUES (?, ?, ?)";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setString(1, gestor.getNome());
        ps.setString(2, gestor.getEmail());
        ps.setString(3, senhaHash);

        ps.executeUpdate();

        ps.close();
    }

    public Gestor pesquisar(int id) throws SQLException {

        String sql = "SELECT * FROM gestores WHERE id = ?";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setInt(1, id);

        ResultSet rs = ps.executeQuery();

        Gestor gestor = null;

        if (rs.next()) {

            gestor = new Gestor();

            gestor.setId(rs.getInt("id"));
            gestor.setNome(rs.getString("nome"));
            gestor.setEmail(rs.getString("email"));
            gestor.setSenhaHash(rs.getString("senha_hash"));
        }

        rs.close();
        ps.close();

        return gestor;
    }

    public void alterar(Gestor gestor) throws SQLException {

        String sql = "UPDATE gestores SET "
                + "nome = ?, "
                + "email = ? "
                + "WHERE id = ?";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setString(1, gestor.getNome());
        ps.setString(2, gestor.getEmail());
        ps.setInt(3, gestor.getId());

        ps.executeUpdate();

        ps.close();
    }

    public void alterarSenha(int id, String novaSenha)
            throws SQLException {

        String senhaHash = BCrypt.hashpw(
                novaSenha,
                BCrypt.gensalt()
        );

        String sql = "UPDATE gestores SET "
                + "senha_hash = ? "
                + "WHERE id = ?";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setString(1, senhaHash);
        ps.setInt(2, id);

        ps.executeUpdate();

        ps.close();
    }

    public void excluir(int id) throws SQLException {

        String sql = "DELETE FROM gestores WHERE id = ?";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setInt(1, id);

        ps.executeUpdate();

        ps.close();
    }

    public Gestor login(String email, String senha) throws SQLException {

    String sql = "SELECT * FROM gestores WHERE email = ?";

    PreparedStatement ps = conexao.prepareStatement(sql);

    ps.setString(1, email);

    ResultSet rs = ps.executeQuery();

    Gestor gestor = null;

    if (rs.next()) {

        String hash = rs.getString("senha_hash");

        if (BCrypt.checkpw(senha, hash)) {

            gestor = new Gestor();

            gestor.setId(rs.getInt("id"));
            gestor.setNome(rs.getString("nome"));
            gestor.setEmail(rs.getString("email"));
        }
    }

    rs.close();
    ps.close();

    return gestor;
}
}