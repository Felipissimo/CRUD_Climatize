/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import model.Funcionario;
import java.sql.SQLException;
import java.util.ArrayList;

public class FuncionarioController {

    private FuncionarioDAO funcionarioDAO;

    public FuncionarioController() {
        funcionarioDAO = new FuncionarioDAO();
    }

    // Cadastrar funcionário
    public void cadastrar(Funcionario funcionario, String senha)
            throws SQLException {

        if (funcionario == null) {
            throw new SQLException("Funcionário inválido.");
        }

        if (funcionario.getNome() == null
                || funcionario.getNome().trim().isEmpty()) {
            throw new SQLException("Informe o nome do funcionário.");
        }

        if (funcionario.getEmail() == null
                || funcionario.getEmail().trim().isEmpty()) {
            throw new SQLException("Informe o e-mail do funcionário.");
        }

        if (senha == null || senha.isEmpty()) {
            throw new SQLException("Informe a senha.");
        }

        if (funcionario.getSetor() == null
                || funcionario.getSetor().trim().isEmpty()) {
            throw new SQLException("Informe o setor.");
        }

        if (funcionario.getCargo() == null
                || funcionario.getCargo().trim().isEmpty()) {
            throw new SQLException("Informe o cargo.");
        }

        funcionarioDAO.cadastrar(funcionario, senha);
    }

    // Pesquisar funcionário
    public Funcionario pesquisar(int id)
            throws SQLException {

        return funcionarioDAO.pesquisar(id);
    }

    // Listar funcionários
    public ArrayList<Funcionario> listar()
            throws SQLException {

        return funcionarioDAO.listar();
    }

    // Alterar funcionário
    public void alterar(Funcionario funcionario)
            throws SQLException {

        if (funcionario == null) {
            throw new SQLException("Funcionário inválido.");
        }

        if (funcionario.getNome() == null
                || funcionario.getNome().trim().isEmpty()) {
            throw new SQLException("Informe o nome do funcionário.");
        }

        if (funcionario.getEmail() == null
                || funcionario.getEmail().trim().isEmpty()) {
            throw new SQLException("Informe o e-mail do funcionário.");
        }

        if (funcionario.getSetor() == null
                || funcionario.getSetor().trim().isEmpty()) {
            throw new SQLException("Informe o setor.");
        }

        if (funcionario.getCargo() == null
                || funcionario.getCargo().trim().isEmpty()) {
            throw new SQLException("Informe o cargo.");
        }

        funcionarioDAO.alterar(funcionario);
    }

    // Alterar senha
    public void alterarSenha(int id, String novaSenha)
            throws SQLException {

        if (novaSenha == null || novaSenha.isEmpty()) {
            throw new SQLException("Informe a nova senha.");
        }

        funcionarioDAO.alterarSenha(id, novaSenha);
    }

    // Excluir funcionário
    public void excluir(int id)
            throws SQLException {

        funcionarioDAO.excluir(id);
    }

    // Login
    public Funcionario login(String email, String senha)
            throws SQLException {

        if (email == null || email.trim().isEmpty()) {
            throw new SQLException("Informe o e-mail.");
        }

        if (senha == null || senha.isEmpty()) {
            throw new SQLException("Informe a senha.");
        }

        return funcionarioDAO.login(email, senha);
    }
}
