/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import model.Funcionario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.mindrot.jbcrypt.BCrypt;

public class FuncionarioDAO {

    private Connection conexao;

    public FuncionarioDAO() {
        try {
            conexao = Conexao.getConexao();
        } catch (SQLException e) {
            System.out.println("Erro ao conectar com o banco: "
                    + e.getMessage());
        }
    }

    public void cadastrar(Funcionario funcionario, String senha)
            throws SQLException {

        String senhaHash = BCrypt.hashpw(
                senha,
                BCrypt.gensalt()
        );

        String sql = "INSERT INTO funcionarios "
                + "(nome, email, senha_hash, setor, cargo) "
                + "VALUES (?, ?, ?, ?, ?)";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setString(1, funcionario.getNome());
        ps.setString(2, funcionario.getEmail());
        ps.setString(3, senhaHash);
        ps.setString(4, funcionario.getSetor());
        ps.setString(5, funcionario.getCargo());

        ps.executeUpdate();

        ps.close();
    }

    public Funcionario pesquisar(int id) throws SQLException {

        String sql = "SELECT * FROM funcionarios WHERE id = ?";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setInt(1, id);

        ResultSet rs = ps.executeQuery();

        Funcionario funcionario = null;

        if (rs.next()) {

            funcionario = new Funcionario();

            funcionario.setId(rs.getInt("id"));
            funcionario.setNome(rs.getString("nome"));
            funcionario.setEmail(rs.getString("email"));
            funcionario.setSenhaHash(rs.getString("senha_hash"));
            funcionario.setSetor(rs.getString("setor"));
            funcionario.setCargo(rs.getString("cargo"));
        }

        rs.close();
        ps.close();

        return funcionario;
    }

    public ArrayList<Funcionario> listar() throws SQLException {

        String sql = "SELECT * FROM funcionarios ORDER BY nome";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        ArrayList<Funcionario> funcionarios = new ArrayList<>();

        while (rs.next()) {

            Funcionario funcionario = new Funcionario();

            funcionario.setId(rs.getInt("id"));
            funcionario.setNome(rs.getString("nome"));
            funcionario.setEmail(rs.getString("email"));
            funcionario.setSenhaHash(rs.getString("senha_hash"));
            funcionario.setSetor(rs.getString("setor"));
            funcionario.setCargo(rs.getString("cargo"));

            funcionarios.add(funcionario);
        }

        rs.close();
        ps.close();

        return funcionarios;
    }

    // Alterar funcionário
    public void alterar(Funcionario funcionario) throws SQLException {

        String sql = "UPDATE funcionarios SET "
                + "nome = ?, "
                + "email = ?, "
                + "setor = ?, "
                + "cargo = ? "
                + "WHERE id = ?";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setString(1, funcionario.getNome());
        ps.setString(2, funcionario.getEmail());
        ps.setString(3, funcionario.getSetor());
        ps.setString(4, funcionario.getCargo());
        ps.setInt(5, funcionario.getId());

        ps.executeUpdate();

        ps.close();
    }

    public void alterarSenha(int id, String novaSenha)
            throws SQLException {

        String senhaHash = BCrypt.hashpw(
                novaSenha,
                BCrypt.gensalt()
        );

        String sql = "UPDATE funcionarios SET "
                + "senha_hash = ? "
                + "WHERE id = ?";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setString(1, senhaHash);
        ps.setInt(2, id);

        ps.executeUpdate();

        ps.close();
    }

    public void excluir(int id) throws SQLException {

        String sql = "DELETE FROM funcionarios WHERE id = ?";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setInt(1, id);

        ps.executeUpdate();

        ps.close();
    }

    public Funcionario login(String email, String senha) throws SQLException {

    String sql = "SELECT * FROM funcionarios WHERE email = ?";

    PreparedStatement ps = conexao.prepareStatement(sql);

    ps.setString(1, email);

    ResultSet rs = ps.executeQuery();

    Funcionario funcionario = null;

    if (rs.next()) {

        String hash = rs.getString("senha_hash");

        if (BCrypt.checkpw(senha, hash)) {

            funcionario = new Funcionario();

            funcionario.setId(rs.getInt("id"));
            funcionario.setNome(rs.getString("nome"));
            funcionario.setEmail(rs.getString("email"));
            funcionario.setSenhaHash(hash);
            funcionario.setSetor(rs.getString("setor"));
            funcionario.setCargo(rs.getString("cargo"));
        }
    }

    rs.close();
    ps.close();

    return funcionario;
}
}
